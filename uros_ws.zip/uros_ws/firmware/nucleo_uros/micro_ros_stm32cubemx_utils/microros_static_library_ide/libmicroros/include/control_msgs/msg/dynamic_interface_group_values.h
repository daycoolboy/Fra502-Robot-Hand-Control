// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/DynamicInterfaceGroupValues.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DYNAMIC_INTERFACE_GROUP_VALUES_H_
#define CONTROL_MSGS__MSG__DYNAMIC_INTERFACE_GROUP_VALUES_H_

#include "control_msgs/msg/detail/dynamic_interface_group_values__struct.h"
#include "control_msgs/msg/detail/dynamic_interface_group_values__functions.h"
#include "control_msgs/msg/detail/dynamic_interface_group_values__type_support.h"

#endif  // CONTROL_MSGS__MSG__DYNAMIC_INTERFACE_GROUP_VALUES_H_
