// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/JointWrenchTrajectoryPoint.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__JOINT_WRENCH_TRAJECTORY_POINT_H_
#define CONTROL_MSGS__MSG__JOINT_WRENCH_TRAJECTORY_POINT_H_

#include "control_msgs/msg/detail/joint_wrench_trajectory_point__struct.h"
#include "control_msgs/msg/detail/joint_wrench_trajectory_point__functions.h"
#include "control_msgs/msg/detail/joint_wrench_trajectory_point__type_support.h"

#endif  // CONTROL_MSGS__MSG__JOINT_WRENCH_TRAJECTORY_POINT_H_
