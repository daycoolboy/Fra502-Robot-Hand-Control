// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/MotionPrimitive.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__MOTION_PRIMITIVE_H_
#define CONTROL_MSGS__MSG__MOTION_PRIMITIVE_H_

#include "control_msgs/msg/detail/motion_primitive__struct.h"
#include "control_msgs/msg/detail/motion_primitive__functions.h"
#include "control_msgs/msg/detail/motion_primitive__type_support.h"

#endif  // CONTROL_MSGS__MSG__MOTION_PRIMITIVE_H_
