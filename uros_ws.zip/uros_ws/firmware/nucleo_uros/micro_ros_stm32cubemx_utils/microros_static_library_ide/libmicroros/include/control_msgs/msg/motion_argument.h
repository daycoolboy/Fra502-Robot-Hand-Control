// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/MotionArgument.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__MOTION_ARGUMENT_H_
#define CONTROL_MSGS__MSG__MOTION_ARGUMENT_H_

#include "control_msgs/msg/detail/motion_argument__struct.h"
#include "control_msgs/msg/detail/motion_argument__functions.h"
#include "control_msgs/msg/detail/motion_argument__type_support.h"

#endif  // CONTROL_MSGS__MSG__MOTION_ARGUMENT_H_
