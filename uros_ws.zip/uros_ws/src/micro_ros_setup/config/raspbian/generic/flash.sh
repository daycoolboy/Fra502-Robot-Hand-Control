#! /bin/bash

source $FW_TARGETDIR/mcu_ws/app_info.sh
echo "Copy $FW_TARGETDIR/bin/$APP_OUTPUT_NAME into your RPi."